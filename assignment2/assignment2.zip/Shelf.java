package assignment2;
//Name:Hanwen Wang        ID:260778557

public class Shelf {
	
	protected int height;
	protected int availableLength;
	protected int totalLength;
	protected Box firstBox;
	protected Box lastBox;

	public Shelf(int height, int totalLength){
		this.height = height;
		this.availableLength = totalLength;
		this.totalLength = totalLength;
		this.firstBox = null;
		this.lastBox = null;
	}
	
	protected void clear(){
		availableLength = totalLength;
		firstBox = null;
		lastBox = null;
	}
	
	public String print(){
		String result = "( " + height + " - " + availableLength + " ) : ";
		Box b = firstBox;
		while(b != null){
			result += b.id + ", ";
			b = b.next;
		}
		result += "\n";
		return result;
	}
	
	/**
	 * Adds a box on the shelf. Here we assume that the box fits in height and length on the shelf.
	 * @param b
	 */
	public void addBox(Box b){
		if(lastBox==null) 
		{
			lastBox=b;
			firstBox=b;
			b.next=null;
			b.previous=null;
			this.availableLength=this.totalLength-lastBox.length;
		}
		else 
		{	
			b.previous=lastBox;
			lastBox.next=b;
			lastBox=b;
			this.availableLength=this.availableLength-lastBox.length;
		}
	}
	
	/**
	 * If the box with the identifier is on the shelf, remove the box from the shelf and return that box.
	 * If not, do not do anything to the Shelf and return null.
	 * @param identifier
	 * @return
	 */
	public Box removeBox(String identifier){
		Box b=firstBox;
		if (firstBox==null)
		{
			return null;
		}
		else if (firstBox.id.equals(identifier))
		{
			Box first=firstBox;
			this.availableLength=this.availableLength+first.length;
			if (firstBox!=lastBox)
			{
				firstBox=first.next;
				firstBox.previous=null;
				first.next=null;
				first.previous=null;
				return first;
			}
			else
			{
				firstBox=null;
				return first;
			}
		}
		else if (lastBox.id.equals(identifier))
		{
			Box last=lastBox;
			this.availableLength=this.availableLength+last.length;
			lastBox=last.previous;
			lastBox.next=null;
			last.previous=null;
			last.next=null;
			return last;
		}
		else if (!firstBox.id.equals(identifier)&&!lastBox.id.equals(identifier)&&firstBox!=null)
		{
			while (b.next!=null)
			{
				b=b.next;
				if (b.id.equals(identifier))
				{
					this.availableLength=this.availableLength+b.length;
					b.previous.next=b.next;
					b.next.previous=b.previous;
					b.next=null;
					b.previous=null;
					return b;
				}
			}
		}
		return null;
	}
}	
